(function(window,document){var Dvideo=function(options){if(!(this instanceof Dvideo))return new Dvideo(options)
this.localValue={ele:'',src:'http://oxyi0vk1f.bkt.clouddn.com/evn4.mp4',title:'这是一个视频标题这是一个视频标题这是一个视频标题这是一个视频标题',width:'420px',height:'250px',showNext:false,autoplay:false,ctrSpeedDuration:3000,loop:true,volume:0.8,showVolume:true,showVolumeUnFull:true,tipsInfo:null,showPlayBackRate:true,playbackRate:{activeIndex:1,rateList:[0.8,1,1.5,2]},showVideoDefinition:true,videoDefinition:{activeIndex:1,definitionList:[{type:'0',name:'标清'},{type:'1',name:'高清'},{type:'2',name:'超清'}]},nextVideoExtend:function(){},setVideoDefinition:function(type,ele,currentT){},onTimeupdate:function(currentT){},onPlaying:function(currentT){},onPause:function(){},onEnded:function(){},onLoadedMetaData:function(){}}
this.opt=this.extend(this.localValue,options,true)
this.isFull=false
this.isLoadMate=false
this.isPlaying=false
this.durationT=0
this.currentT=0
this.showCtrlT=''
this.currentP=0
this.isDrag=false
this.onpress=false
this.maxProgressWidth=0
this.dragProgressTo=0
this.volume=1
this.maxVolumeWidth=0
this.dragVolumeTo=0
this.browserV=this.browserVersion()
this.reduceTBefore=0
this.reduceTAfter=0
if((typeof options.ele)==="string"){this.opt.ele=document.querySelector(options.ele)}else{this.opt.ele=options.ele}
this.isPlaying=this.opt.autoplay
this.initDom()
this.showTopBottomCtrl(true)}
Dvideo.prototype={constructor:this,initDom:function(){this.opt.ele.style.width=this.opt.width
this.opt.ele.style.height=this.opt.height
this.createVideoC()
this.createVideoEle()
this.createHeaderC()
this.createCtrlC()
this.createvideoPlayState()
this.createPcProgress()
this.createCurrentDurationText()
this.menuRightC=document.createElement('div')
this.menuRightC.className='Dvideo-menu-right-content'
this.videoCtrlDetail.appendChild(this.menuRightC)
if(this.opt.showVolume){this.createVolume()}
if(this.opt.showPlayBackRate){this.createPlaybackRateList()}
if(this.opt.showVideoDefinition){this.createVideoDefinition()}
this.createSelectVideoFull()
this.createVideoTips()
this.initEvent()},extend:function(o,n,override){for(var key in n){if(n.hasOwnProperty(key)&&(!o.hasOwnProperty(key)||override)){o[key]=n[key]}}
return o},launchFullScreen:function(element){if(this.browserV.indexOf('IE10')>=0||this.browserV.indexOf('IE9')>=0){console.log('启用IE全屏')
this.launchFullScreenIE11L();}else{if(element.requestFullscreen){element.requestFullscreen()}else if(element.mozRequestFullScreen){element.mozRequestFullScreen()}else if(element.webkitRequestFullscreen){element.webkitRequestFullscreen()}else if(element.msRequestFullscreen){element.msRequestFullscreen()}
console.log('启用全屏 包括ie11')
this.launchFullScreenStyle(element)}
this.updateFullScreenState(true)},launchFullScreenStyle:function(){this.opt.ele.style.width='100%'
this.opt.ele.style.height='100%'},launchFullScreenIE11L:function(){var cName=this.opt.ele.className
this.opt.ele.className=cName+' ie-fullscreen'},exitFullscreen:function(){if(this.browserV.indexOf('IE10')>=0||this.browserV.indexOf('IE9')>=0){console.log('启用IE9 IE10全屏')
this.exitFullscreenIE11L();}else{if(document.exitFullscreen){document.exitFullscreen();}else if(document.mozCancelFullScreen){document.mozCancelFullScreen();}else if(document.webkitExitFullscreen){document.webkitExitFullscreen();}else if(document.msExitFullscreen){document.msExitFullscreen();}}},exitFullscreenIE11L:function(){console.log('关闭全屏 IE 10及以下')
this.updateFullScreenState(false)
var cName=this.opt.ele.className
this.opt.ele.className=cName.split(' ').slice(cName.split(' ').indexOf('ie-fullscreen'),1)
this.opt.ele.style.width=this.opt.width
this.opt.ele.style.height=this.opt.height},exitFullScreenStyle:function(){console.log('关闭全屏 其他浏览器 和 非IE11以下')
this.updateFullScreenState(false)
this.opt.ele.style.width=this.opt.width
this.opt.ele.style.height=this.opt.height},updateVideoSize:function(width,height){if(!(width&&height)){throw Error('noneeleerror','请填写信息')
return;}
console.log('改变video的宽高')
this.updateFullScreenState(false)
this.opt.ele.style.width=width+'px'
this.opt.ele.style.height=height+'px'
this.opt.width=width+'px'
this.opt.height=height+'px'},updateFullScreenState:function(bool){this.isFull=bool||false
var iconClassName=this.isFull?'Dvideo-menu-fullscreenConfig icon-canclefullscreen':'Dvideo-menu-fullscreenConfig icon-fullscreen'
var title=this.isFull?'取消全屏':'全屏'
this.fullscreenConfig.className=iconClassName
this.fullscreenConfig.title=title
var videoClassName=this.isFull?'Dvideo-content full':'Dvideo-content'
this.videoC.className=videoClassName},screenChangeEvent:function(element){var _this=this
if(_this.browserV.indexOf('IE11')>=0){document.onkeydown=function(e){var keyNum=window.event?e.keyCode:e.which
if(keyNum===27&&_this.isFull){_this.exitFullScreenStyle()}}}
else if(this.browserV.indexOf('IE10')>=0||this.browserV.indexOf('IE9')>=0){document.onkeydown=function(e){var keyNum=window.event?e.keyCode:e.which
if(keyNum===27&&_this.isFull){_this.exitFullscreenIE11L()}}}
else{var eventList=['webkitfullscreenchange','mozfullscreenchange','fullscreenchange','msfullscreenchange']
for(var i=0;i<eventList.length;i++){document.addEventListener(eventList[i],function(){var fullscreenElement=document.fullscreenElement||document.mozFullScreenElement||document.webkitFullscreenElement||document.msFullscreenElement
var isFullScreen=document.fullScreen||document.mozFullScreen||document.webkitIsFullScreen||document.msIsFullScreen
if(fullscreenElement){console.log('全屏')
_this.launchFullScreenStyle(_this.opt.ele);}else{console.log('不是全屏')
_this.exitFullScreenStyle()}})}}},browserVersion:function(){var userAgent=navigator.userAgent,rMsie=/(msie\s|trident.*rv:)([\w.]+)/,rFirefox=/(firefox)\/([\w.]+)/,rOpera=/(opera).+version\/([\w.]+)/,rChrome=/(chrome)\/([\w.]+)/,rSafari=/version\/([\w.]+).*(safari)/;var browser;var version;var ua=userAgent.toLowerCase();function uaMatch(ua){var match=rMsie.exec(ua);if(match!=null){return{browser:"IE",version:match[2]||"0"};}
var match=rFirefox.exec(ua);if(match!=null){return{browser:match[1]||"",version:match[2]||"0"};}
var match=rOpera.exec(ua);if(match!=null){return{browser:match[1]||"",version:match[2]||"0"};}
var match=rChrome.exec(ua);if(match!=null){return{browser:match[1]||"",version:match[2]||"0"};}
var match=rSafari.exec(ua);if(match!=null){return{browser:match[2]||"",version:match[1]||"0"};}
if(match!=null){return{browser:"",version:"0"};}}
var browserMatch=uaMatch(userAgent.toLowerCase());if(browserMatch.browser){browser=browserMatch.browser;version=browserMatch.version;}
return browser+version},showTopBottomCtrl:function(disappearance){clearTimeout(this.showCtrlT)
this.videoCtrl.className='Dvideo-ctrl active'
this.videoHeader.className='Dvideo-header active'
if(disappearance){this.hideTopBottomCtrl()}},hideTopBottomCtrl:function(immediately){clearTimeout(this.showCtrlT)
var _this=this
if(immediately){this.videoCtrl.className='Dvideo-ctrl'
this.videoHeader.className='Dvideo-header'
this.hideProgressRange()}else{this.showCtrlT=setTimeout(function(){_this.videoCtrl.className='Dvideo-ctrl'
_this.videoHeader.className='Dvideo-header'
_this.hideProgressRange()},_this.opt.ctrSpeedDuration)}},showProgressRange:function(){this.videoProressC.className='Dvideo-progress-content active'},hideProgressRange:function(){this.videoProressC.className='Dvideo-progress-content'},videoPlay:function(){try{this.videoEle.play();this.isPlaying=true}catch(e){console.log(e)}},videoPause:function(){try{this.videoEle.pause();this.isPlaying=false
console.log(this.isPlaying+'222222')}catch(e){console.log(e)}},videoPlayPause:function(){console.log(this.isPlaying+'--------------')
if(this.isPlaying){this.videoPause();}else{this.videoPlay();}},showLoading:function(bool,text){var text=text||'视频加载中,请稍等  或者切换稍低的清晰度'
if(bool){this.tipsInfo.innerText=text
this.tipsInfo.className='Dvideo-tips-info'}else{this.tipsInfo.className='Dvideo-tips-info hide'}},videoForward:function(seconds){if(this.videoEle.currentTime){this.currentT=this.currentT+10>this.durationT?this.durationT:this.currentT+10
this.videoEle.currentTime=this.currentT
this.updatePorgress()}},videoRewind:function(seconds){if(this.videoEle.currentTime){this.currentT=this.currentT-10<0?0:this.currentT-10
this.videoEle.currentTime=this.currentT
this.updatePorgress()}},initEvent:function(){var _this=this
document.onkeydown=function(e){var e=e||window.event
if((e.keyCode||e.which||e.charCode)===32){e.stopPropagation();e.preventDefault();_this.videoPlayPause()}
if((e.keyCode||e.which||e.charCode)===39){e.stopPropagation();e.preventDefault();_this.showTopBottomCtrl()
_this.videoForward(10)}
if((e.keyCode||e.which||e.charCode)===37){e.stopPropagation();e.preventDefault();_this.showTopBottomCtrl()
_this.videoRewind(10)}
if((e.keyCode||e.which||e.charCode)===38){e.stopPropagation();e.preventDefault();_this.showTopBottomCtrl()
_this.volume=_this.volume*1+0.02>1?1:_this.volume*1+0.02
_this.setVolume()}
if((e.keyCode||e.which||e.charCode)===40){e.stopPropagation();e.preventDefault();_this.showTopBottomCtrl()
_this.volume=_this.volume*1-0.02<0?0:_this.volume*1-0.02
_this.setVolume()}}
_this.screenChangeEvent()},onPlaying:function(){this.opt.onPlaying(this.currentT)},onPause:function(){this.opt.onPause()},onLoadedMetaData:function(){this.opt.onLoadedMetaData()},onTimeupdate:function(){this.opt.onTimeupdate(this.currentT)},onEnded:function(){this.opt.onEnded()},formartTime:function(seconds){var formatNumber=function(n){n=n.toString()
return n[1]?n:'0'+n}
var m=Math.floor(seconds/60);var s=Math.floor(seconds%60);return formatNumber(m)+":"+formatNumber(s);},setVideoDefinition:function(e){this.showLoading(true,'视频清晰度切换中，请稍等')
var index=e.target.getAttribute('data-index')
var type=e.target.getAttribute('data-type')
this.currentT=this.videoEle.currentTime
this.opt.videoDefinition={activeIndex:index,definitionList:this.opt.videoDefinition.definitionList}
this.videoDefinitionText.title=this.opt.videoDefinition.definitionList[index].name
this.videoDefinitionText.innerText=this.opt.videoDefinition.definitionList[index].name
this.setLStorage('D-videoDefinition',JSON.stringify(this.opt.videoDefinition))
this.getDomByClass('Dvideo-definition-list active')[0].className='Dvideo-definition-list'
e.target.className='Dvideo-definition-list active'
this.videoDefinitionC.style.display='none'
this.opt.setVideoDefinition(type,e,this.currentT)},setVideoInfo:function(title,url,currentT){var _this=this
this.isLoadMate=false
this.isPlaying=false
this.videoEle.src=url||'',this.videoHeaderTitle.innerText=title||'这是一个title'
this.videoHeaderTitle.title=title||'这是一个title'
var loadProPlay=function(){if(_this.isLoadMate){clearInterval(loadTime)
_this.videoEle.currentTime=currentT||0}
_this.videoPlay();}
var loadTime=setInterval(function(){loadProPlay();},500)},setPlayBackRate:function(index){this.playbackR=this.opt.playbackRate.rateList[index]
this.videoEle.playbackRate=this.playbackR
this.playbackRateText.title=this.playbackR.toFixed(1)+' x'
this.playbackRateText.innerText=this.playbackR.toFixed(1)+' x'
this.opt.playbackRate={activeIndex:index,rateList:this.opt.playbackRate.rateList}
this.setLStorage('D-playbackRate',JSON.stringify(this.opt.playbackRate))
this.getDomByClass('Dvideo-playbackRate-list active')[0].className='Dvideo-playbackRate-list'
this.getDomByClass('Dvideo-playbackRate-list')[index].className='Dvideo-playbackRate-list active'
this.playbackRateC.style.display='none'},updatePorgress:function(isDrag){var isDrag=isDrag||false
if(isDrag){this.circleRange.style.left=this.dragProgressTo+'px'
this.realProress.style.width=this.dragProgressTo+'px'
var currentTime=Math.floor(this.dragProgressTo/this.maxProgressWidth*this.durationT)
this.textCurrentT.innerText=this.formartTime(currentTime)}else{this.currentP=Number((this.currentT/this.durationT)*100)
this.currentP=this.currentP>100?100:this.currentP
this.realProress.style.width=this.currentP+'%'
this.circleRange.style.left=this.currentP+'%'
this.textCurrentT.innerText=this.formartTime(this.videoEle.currentTime)}},nextVideo:function(){console.log('你点击了播放下一集   可使用实例化的对象调用nextVideo 方法实现播放下一集的效果')
if(typeof this.opt.nextVideoExtend==='function')this.opt.nextVideoExtend()},setVolume:function(){var persent=this.volume/1
this.updateVolume(persent)},createPlaybackRateList:function(){var oFragment=document.createDocumentFragment();var playbackrateData=this.hasLStorage('D-playbackRate')?JSON.parse(this.getLStorage('D-playbackRate')):this.opt.playbackRate
var playbackrateIndex=Number(playbackrateData.activeIndex)
var playbackR=Number(playbackrateData.rateList[playbackrateIndex])
this.playbackRate=document.createElement('span')
this.playbackRate.className='Dvideo-playbackRate'
this.menuRightC.appendChild(this.playbackRate)
this.playbackRateText=document.createElement('span')
this.playbackRateText.className='Dvideo-playbackRateText'
this.videoEle.playbackRate=playbackR
this.playbackRateText.title=playbackR.toFixed(1)+' x'
this.playbackRateText.innerText=playbackR.toFixed(1)+' x'
this.playbackRate.appendChild(this.playbackRateText)
this.playbackRateC=document.createElement('div')
this.playbackRateC.className='Dvideo-playbackRate-content'
this.playbackRate.appendChild(this.playbackRateC)
for(var i=0;i<playbackrateData.rateList.length;i++){var playbackRateL=document.createElement('span')
if(i===playbackrateIndex){playbackRateL.className='Dvideo-playbackRate-list active'}else{playbackRateL.className='Dvideo-playbackRate-list'}
playbackRateL.title=playbackrateData.rateList[i].toFixed(1)+'x'
playbackRateL.innerText=playbackrateData.rateList[i].toFixed(1)+'x'
playbackRateL.setAttribute('data-index',i)
oFragment.appendChild(playbackRateL)}
this.playbackRateC.appendChild(oFragment)
var _this=this
_this.playbackRate.onmouseenter=function(event){_this.playbackRateC.style.display='block'}
_this.playbackRate.onmouseleave=function(event){_this.playbackRateC.style.display='none'}
_this.playbackRateC.onclick=function(event){var e=event||window.event
var index=e.target.getAttribute('data-index')
_this.setPlayBackRate(index)}},createCurrentDurationText:function(){var oFragment=document.createDocumentFragment();this.textVideoTimeC=document.createElement('div')
this.textVideoTimeC.className='Dvideo-time-content'
this.videoCtrlDetail.appendChild(this.textVideoTimeC)
this.textCurrentT=document.createElement('span')
this.textCurrentT.className='Dvideo-text-current'
this.textCurrentT.innerText='--:-- '
oFragment.appendChild(this.textCurrentT)
this.textDurationT=document.createElement('span')
this.textDurationT.className='Dvideo-text-duration'
this.textDurationT.innerText=' --:--'
oFragment.appendChild(this.textDurationT)
this.textVideoTimeC.appendChild(oFragment)},createPcProgress:function(){this.videoProressC=document.createElement('div')
this.videoProressC.className='Dvideo-progress-content'
this.videoCtrl.appendChild(this.videoProressC)
this.videoProressD=document.createElement('div')
this.videoProressD.className='Dvideo-progress-detail'
this.videoProressC.appendChild(this.videoProressD)
this.bufferedProress=document.createElement('div')
this.bufferedProress.className='Dvideo-progress-buffered'
this.videoProressD.appendChild(this.bufferedProress)
this.realProress=document.createElement('div')
this.realProress.className='Dvideo-progress-real'
this.videoProressD.appendChild(this.realProress)
this.circleRange=document.createElement('span')
this.circleRange.className='Dvideo-circle-range'
this.videoProressC.appendChild(this.circleRange)
var _this=this
_this.videoProressD.onclick=function(event){var e=event||window.event
var videoProgressCW=_this.videoProressD.offsetWidth
var eW=e.offsetX
_this.videoEle.currentTime=_this.currentT=Math.floor(eW/videoProgressCW*_this.durationT)
_this.updatePorgress()}
_this.circleRange.onmousedown=function(event){_this.isDrag=true
var e=event||window.event
var x=e.clientX
var l=event.target.offsetLeft+7
e.stopPropagation()
_this.maxProgressWidth=_this.videoProressD.offsetWidth
_this.videoCtrl.onmousemove=function(event){var e=event||window.event
if(_this.isDrag){var thisX=e.clientX
_this.dragProgressTo=Math.min(_this.maxProgressWidth,Math.max(0,l+(thisX-x)))
_this.updatePorgress(true)}}
_this.videoCtrl.onmouseup=function(event){var e=event||window.event
e.stopPropagation()
if(_this.isDrag){_this.isDrag=false
_this.videoEle.currentTime=Math.floor(_this.dragProgressTo/_this.maxProgressWidth*_this.durationT)}else{return}}
_this.videoCtrl.onmouseleave=function(event){var e=event||window.event
e.stopPropagation()
if(_this.isDrag){_this.isDrag=false
_this.videoEle.currentTime=Math.floor(_this.dragProgressTo/_this.maxProgressWidth*_this.durationT)}else{return}
_this.hideTopBottomCtrl()}}},createVideoEle:function(){this.videoEle=document.createElement('video')
this.videoEle.className='Dvideo-ele'
this.videoEle.src=this.opt.src
this.videoEle.loop=this.opt.loop
this.videoEle.autoplay=this.opt.autoplay
this.videoC.appendChild(this.videoEle)
var _this=this
_this.videoEle.onloadstart=function(){_this.showLoading(true,'视频加载中，请稍等')},_this.videoEle.oncanplay=function(){_this.showLoading(false)},_this.videoEle.onplaying=function(){_this.isPlaying=true
_this.videoPlayPauseI.className='Dvideo-ctrl-playPause icon-pause'
_this.videoPlayPauseI.title='暂停 space'
var date=new Date()
_this.reduceTBefore=Date.parse(date)-Math.floor(_this.videoEle.currentTime*1000)
_this.showLoading(false)
_this.onPlaying()},_this.videoEle.onpause=function(){_this.isPlaying=false
_this.videoPlayPauseI.className='Dvideo-ctrl-playPause icon-play'
_this.videoPlayPauseI.title='播放 space'
_this.onPause()},_this.videoEle.onloadedmetadata=function(){_this.isLoadMate=true
_this.durationT=_this.videoEle.duration
_this.textDurationT.innerText=_this.formartTime(_this.durationT)
_this.onLoadedMetaData()},_this.videoEle.ontimeupdate=function(){if(!_this.isDrag){_this.currentT=_this.videoEle.currentTime
_this.updatePorgress()
var date=new Date()
_this.reduceTBefore=Date.parse(date)-Math.floor(_this.currentT*1000)}
_this.onTimeupdate()},_this.videoEle.onprogress=function(){if(_this.videoEle.buffered.length>0){var bufferedT=0
for(var i=0;i<_this.videoEle.buffered.length;i++){bufferedT+=_this.videoEle.buffered.end(i)-_this.videoEle.buffered.start(i)
if(bufferedT>_this.durationT){bufferedT=_this.durationT
console.log('缓冲完成')}}
var bufferedP=Math.floor((bufferedT/_this.durationT)*100)
_this.bufferedProress.style.width=bufferedP+'%'}else{console.log('未缓冲')}
var date=new Date()
if(!_this.videoEle.paused){_this.reduceTAfter=Date.parse(date)-Math.floor(_this.currentT*1000)
console.log(_this.reduceTAfter)
if(_this.reduceTAfter-_this.reduceTBefore>1000){_this.showLoading(true)}else{_this.showLoading(false)}}else{return}}
_this.videoEle.onended=function(){_this.onEnded();}
_this.videoEle.onwaiting=function(){_this.showLoading(true,'视频加载中,请稍等')}},createVideoC:function(){this.videoC=document.createElement('div')
this.videoC.className='Dvideo-content'
this.opt.ele.appendChild(this.videoC)
var _this=this
_this.videoC.onmousemove=function(){_this.showTopBottomCtrl(true)}
var startTime=0;_this.videoC.onclick=function(){var date=(new Date()).valueOf();if(date-startTime>500){if(_this.isPlaying){_this.videoPause()}else{_this.videoPlay()}}else{if(_this.isFull){_this.exitFullscreen()}else{_this.launchFullScreen(_this.opt.ele)}}
startTime=date}},createCtrlC:function(){this.videoCtrl=document.createElement('div')
this.videoCtrl.className='Dvideo-ctrl'
this.videoC.appendChild(this.videoCtrl)
this.videoCtrlDetail=document.createElement('div')
this.videoCtrlDetail.className='Dvideo-detail'
this.videoCtrl.appendChild(this.videoCtrlDetail)
var _this=this
_this.videoCtrl.onmouseenter=function(){_this.showProgressRange()}
_this.videoCtrl.onclick=function(e){e.stopPropagation();}},createHeaderC:function(){this.videoHeader=document.createElement('div')
this.videoHeader.className='Dvideo-header'
this.videoC.appendChild(this.videoHeader)
this.videoHeaderTitle=document.createElement('p')
this.videoHeaderTitle.className='Dvideo-header-title'
this.videoHeaderTitle.innerText=this.opt.title
this.videoHeaderTitle.title=this.opt.title
this.videoHeader.appendChild(this.videoHeaderTitle)
var _this=this
_this.videoHeader.onclick=function(e){e.stopPropagation();}},createSelectVideoFull:function(){var iconFullScreenITitle=this.isFull?'全屏':'取消全屏'
this.fullscreenConfig=document.createElement('i')
this.fullscreenConfig.className='Dvideo-menu-fullscreenConfig icon-fullscreen'
this.fullscreenConfig.title=iconFullScreenITitle
this.menuRightC.appendChild(this.fullscreenConfig)
this.updateFullScreenState(this.isFull)
var _this=this
_this.fullscreenConfig.onclick=function(){if(_this.isFull){_this.exitFullscreen()}else{_this.launchFullScreen(_this.opt.ele)}}},createvideoPlayState:function(){this.videoCtrlStateC=document.createElement('div')
this.videoCtrlStateC.className='Dvideo-ctrl-state'
this.videoCtrlDetail.appendChild(this.videoCtrlStateC)
var iconPlayPauseClass=this.isPlaying?'icon-pause':'icon-play'
var iconPlayPauseITitle=this.isPlaying?'暂停 space':'播放 space'
this.videoPlayPauseI=document.createElement('i')
this.videoPlayPauseI.className='Dvideo-ctrl-playPause '+iconPlayPauseClass
this.videoPlayPauseI.title=iconPlayPauseITitle
this.videoCtrlStateC.appendChild(this.videoPlayPauseI)
var displayStyle=this.opt.showNext?'inline-block':'none'
this.videoNextI=document.createElement('i')
this.videoNextI.className='Dvideo-ctrl-next icon-nextdetail'
this.videoNextI.title='下一集 next'
this.videoNextI.style.display=displayStyle
this.videoCtrlStateC.appendChild(this.videoNextI)
var _this=this
_this.videoNextI.onclick=function(){_this.nextVideo()}
_this.videoPlayPauseI.onclick=function(){if(_this.isPlaying){_this.videoPause()}else{_this.videoPlay()}}},createVideoTips:function(){this.tipsInfo=document.createElement('div')
this.tipsInfo.className='Dvideo-tips-info'
this.videoCtrl.appendChild(this.tipsInfo)},createVideoDefinition:function(){var oFragment=document.createDocumentFragment();var videoDefinitionData=this.hasLStorage('D-videoDefinition')?JSON.parse(this.getLStorage('D-videoDefinition')):this.opt.videoDefinition
var videoDefinitionIndex=Number(videoDefinitionData.activeIndex)
var videoDefinitionType=videoDefinitionData.definitionList[videoDefinitionIndex].type
var videoDefinitionName=videoDefinitionData.definitionList[videoDefinitionIndex].name
this.videoDefinition=document.createElement('span')
this.videoDefinition.className='Dvideo-definition'
this.menuRightC.appendChild(this.videoDefinition)
this.videoDefinitionText=document.createElement('span')
this.videoDefinitionText.className='Dvideo-definitionText'
this.videoDefinitionText.title=videoDefinitionName
this.videoDefinitionText.innerText=videoDefinitionName
this.videoDefinition.appendChild(this.videoDefinitionText)
this.videoDefinitionC=document.createElement('div')
this.videoDefinitionC.className='Dvideo-definition-content'
this.videoDefinition.appendChild(this.videoDefinitionC)
for(var i=0;i<videoDefinitionData.definitionList.length;i++){var videoDefinitionL=document.createElement('span')
if(i===videoDefinitionIndex){videoDefinitionL.className='Dvideo-definition-list active'}else{videoDefinitionL.className='Dvideo-definition-list'}
videoDefinitionL.title=videoDefinitionData.definitionList[i].name
videoDefinitionL.innerText=videoDefinitionData.definitionList[i].name
videoDefinitionL.setAttribute('data-index',i)
videoDefinitionL.setAttribute('data-type',videoDefinitionData.definitionList[i].type)
oFragment.appendChild(videoDefinitionL)}
this.videoDefinitionC.appendChild(oFragment)
var _this=this
_this.videoDefinition.onmouseenter=function(event){_this.videoDefinitionC.style.display='block'}
_this.videoDefinition.onmouseleave=function(event){_this.videoDefinitionC.style.display='none'}
_this.videoDefinition.onclick=function(event){var e=event||window.event
_this.setVideoDefinition(e)}},createVolume:function(){var showVClassName=this.opt.showVolumeUnFull?'':'none'
this.videoVolumeC=document.createElement('div')
this.videoVolumeC.className='Dvideo-volume '+showVClassName
this.menuRightC.appendChild(this.videoVolumeC)
this.videoVolumeP=document.createElement('div')
this.videoVolumeP.className='Dvideo-volume-P'
this.videoVolumeC.appendChild(this.videoVolumeP)
this.videoVolumeR=document.createElement('div')
this.videoVolumeR.className='Dvideo-volume-R'
this.videoVolumeP.appendChild(this.videoVolumeR)
this.videoVolumeRange=document.createElement('div')
this.videoVolumeRange.className='Dvideo-volume-range'
this.videoVolumeC.appendChild(this.videoVolumeRange)
this.initVolume();var isDrag=false
var _this=this
var persent=0
_this.videoVolumeRange.onmousedown=function(event){isDrag=true
var e=event||window.event
var x=e.clientX
var l=event.target.offsetLeft+6
e.stopPropagation()
_this.maxVolumeWidth=_this.videoVolumeC.offsetWidth
_this.videoVolumeC.onmousemove=function(event){if(isDrag){var e=event||window.event
var thisX=e.clientX
_this.dragVolumeTo=Math.min(_this.maxVolumeWidth,Math.max(0,l+(thisX-x)))
persent=_this.dragVolumeTo/_this.maxVolumeWidth
_this.updateVolume(persent);}}
_this.videoVolumeC.onmouseup=function(event){isDrag=false
e.stopPropagation()
e.preventDefault()
_this.setLStorage('Dvideo-volume',persent)
return}
_this.videoVolumeC.onmouseleave=function(event){isDrag=false
e.stopPropagation()
e.preventDefault()
_this.setLStorage('Dvideo-volume',persent)
return}}
_this.videoVolumeP.onclick=function(event){var e=event||window.event
var videoVolumeCW=_this.videoVolumeP.offsetWidth
var eW=e.offsetX
_this.updateVolume(eW/videoVolumeCW);}},updateVolume:function(persent){this.videoVolumeRange.style.left=persent*100+'%'
this.videoVolumeR.style.width=persent*100+'%'
this.videoVolumeRange.setAttribute('data-volume',Math.round(persent*100))
this.volume=persent
this.videoEle.volume=persent
this.setLStorage('Dvideo-volume',persent)},initVolume:function(){if(this.getLStorage('Dvideo-volume')===null){this.updateVolume(0.8)
this.volume=0.8}else{var persent=this.getLStorage('Dvideo-volume')
this.updateVolume(persent)
this.volume=persent}},getDomByClass:function(classInfo){var classInfo=classInfo||'';if(!typeof(document.getElementsByClassName)==='function'){var result=[];var aEle=document.getElementsByTagName('*');var re=new RegExp("\\b"+classInfo+"\\b","g");for(var i=0;i<aEle.length;i++){if(aEle[i].className.search(re)!=-1){result.push(aEle[i]);}}
return result;}else{return document.getElementsByClassName(classInfo);}},lStorage:function(){if(window.localStorage){return true;}else{return false;}},hasLStorage:function(storage_name){var _this=this
if(this.lStorage){return!(window.localStorage.getItem(storage_name)==='undefind'||window.localStorage.getItem(storage_name)===null)}else{return false}},setLStorage:function(key,value){if(this.lStorage){window.localStorage.setItem(key,value)}},getLStorage:function(key){if(this.lStorage){var getLs=window.localStorage.getItem(key)
return getLs}else{return ''}},rmLStorage:function(key){if(this.lStorage){window.localStorage.removeItem(key)}},clearLStorage:function(){if(this.lStorage){window.localStorage.clear()}},}
window.Dvideo=Dvideo;})(window,document)